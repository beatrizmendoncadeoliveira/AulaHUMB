package br.com.fiap.bo;

import br.com.fiap.dao.AssinaturaDAO;
import br.com.fiap.dao.UsuarioDAO;
import br.com.projeto.beans.Assinatura;
import br.com.projeto.beans.Usuario;

public class AssinaturaBO {
	//classe sem atributos -->METODOS ESTATICOS  no BO -->Sempre
	//retorno como string ou int tanto faz
	//throws joga na proxima camada ate chegar no main
	
	public static String novaAssinatura(Assinatura objeto) throws Exception{
		
		//o q quebra sistema � req funcional exemplo se exceder de 15 e quebrar banco
		//detalhes 
		
		
		//regra de negocio
		if(objeto.getCodigo()<=0) {
			return "C�digo invalido";
		}
		if(objeto.getValor()<0) {
			return "Valor nao pode ser negativo";
		}
		//requisito funcional
		if(objeto.getTipo().length()>15) {
			return "Tipo excedeu qtde de caracteres";
		}
		//padronizacao
		objeto.setTipo(objeto.getTipo().toUpperCase());
	
		//fk precisa existir
		//pk precisa ser unica
		
		
		//verificando se a fk existe
		UsuarioDAO usuDao=new UsuarioDAO();
		Usuario objUsuario=usuDao.getUser(objeto.getUsuario().getCodigo());
		//o metodo get User retorna um objeto usuario, entao cria o Usuario objUsuario para receber
		
		//fechar o dao
		usuDao.encerrar();
		if(objUsuario.getCodigo()==0) {
			return "Usuario nao existe";
		}
		//bo valida sempre o errado, se existir ele vai deixar passar
		//verificar se a pk  nao existe pq ela nao pode exitir para ser criado uma nova assinatura
		AssinaturaDAO assDAO=new AssinaturaDAO();
		Assinatura objAssinatura=assDAO.getAssinatura(objeto.getCodigo());
		//este metodo retorna uma assinatura por isso temos que criar um obejto assinatura
		
		if(objAssinatura.getCodigo()>0) {
			return "Codigo da assinatura ja existe";
		}
		//finalmente ...
		int x=assDAO.addAssinatura(objeto);
		
		//fechar o dao
		
		assDAO.encerrar();
		if(x==0) {
			return "Assinatura nao cadastrada";
		}else {
			return "Assinatura cadastrada";
		}
		
		
		
	}

}
