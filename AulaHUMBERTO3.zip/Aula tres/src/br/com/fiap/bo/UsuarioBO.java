package br.com.fiap.bo;

import br.com.fiap.dao.AssinaturaDAO;
import br.com.fiap.dao.UsuarioDAO;
import br.com.projeto.beans.Usuario;

public class UsuarioBO {
	
	public int novoUsuario(Usuario objetoUsuario)throws Exception {
		  if(objetoUsuario.getNome().length()>50) {
			  throw new RuntimeException( "Excedeu caracteres");
		  }
		  if(objetoUsuario.getNome().length()<=3) {
			  throw new RuntimeException("Poucos caracteres");
			  
		  }
		  if(objetoUsuario.getSenha().length()<3|| objetoUsuario.getSenha().length()>15) {
			  throw new RuntimeException("Senha deve estar entre 4 e 15");
		  }
		  objetoUsuario.setNome(objetoUsuario.getNome().toUpperCase());
		  
		  UsuarioDAO dao=new UsuarioDAO();
		  if(dao.getUser(objetoUsuario.getCodigo()).getCodigo()==0) {
			  dao.addUser(objetoUsuario);
			  dao.encerrar();
			  return 1;
			  
		  }else {
			  return 0;
		  }
		  
		  
	}
	public String excluirUsuario(int codigo) throws Exception{
		if(codigo<=0) {
			return "Codigo invalido";
		}
		UsuarioDAO dao=new UsuarioDAO();
		if(dao.getUser(codigo).getCodigo()==0) {
			dao.encerrar();
			return "Usuario nao existe";
		}
		AssinaturaDAO dao2=new AssinaturaDAO();
		if(dao2.verificarUsuario(codigo)==true) {
			return "Usuario em uso";
			
		}
		dao.killUser(codigo);
		dao.encerrar();
		dao2.encerrar();
		
		return"Usuario excluido";
		
		
	}

}
