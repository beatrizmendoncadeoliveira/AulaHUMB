package br.com.fiap.principal;

import javax.swing.JOptionPane;

import br.com.fiap.dao.AssinaturaDAO;
import br.com.projeto.beans.Assinatura;
import br.com.projeto.beans.Usuario;

public class TesteGravarAssinatura {

	public static void main(String[] args) {
		AssinaturaDAO dao=null;
		
		try {
				dao=new AssinaturaDAO();
				Assinatura a=new Assinatura();
				
				
				a.setCodigo(Integer.parseInt(JOptionPane.showInputDialog("codigo:")));
				a.setData(JOptionPane.showInputDialog("Data:"));
				a.setTipo(JOptionPane.showInputDialog("Tipo:"));
				a.setValor(Double.parseDouble(JOptionPane.showInputDialog("Valor:")));
			
				Usuario u=new Usuario();
				u.setCodigo(Integer.parseInt(JOptionPane.showInputDialog("Codigo do usuario")));
				u.setNome(JOptionPane.showInputDialog("Nome do usuario"));
				u.setSenha(JOptionPane.showInputDialog("Digite a senha"));
				a.setUsuario(u);
			
				
				if(dao.addAssinatura(a)==0) {
					System.out.println("Nao foi cadastrado!");
				}else {
					System.out.println("Foi cadastrado!");
				}
			
		
			
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			try {
				dao.encerrar();
				
			}catch(Exception e) {
				e.printStackTrace();
			}
		}

	}

}
