package br.com.fiap.principal;

import javax.swing.JOptionPane;

import br.com.fiap.bo.UsuarioBO;
import br.com.projeto.beans.Usuario;

public class TesteExcluirUsuario {

	public static void main(String[] args) {
		try {
		
		Usuario u=new Usuario();
		u.setCodigo(Integer.parseInt(JOptionPane.showInputDialog("Digite o codigo de usuario")));
		UsuarioBO bo=new UsuarioBO();
		bo.excluirUsuario(u.getCodigo());
		

	}catch(Exception e) {
		e.printStackTrace();
	}
		}
	

}
