package br.com.fiap.principal;

import javax.swing.JOptionPane;

import br.com.fiap.bo.UsuarioBO;
import br.com.fiap.dao.UsuarioDAO;
import br.com.projeto.beans.Usuario;

public class TesteNovoCadastrar {

	public static void main(String[] args) {
	try {UsuarioBO bo=new UsuarioBO();
		Usuario u=new Usuario();
	
		u.setCodigo(Integer.parseInt(JOptionPane.showInputDialog("Digite o codigo")));
		u.setNome(JOptionPane.showInputDialog("Digite seu nome"));
		u.setSenha(JOptionPane.showInputDialog("Digite sua senha"));
	
		
		if(bo.novoUsuario(u)==1) {
			System.out.println("Cadastrado com sucesso");
			
			}else {
				System.out.println("Nao cadastrado");
			}
		
		}catch(Exception e) {
			e.printStackTrace();
		}

}}
