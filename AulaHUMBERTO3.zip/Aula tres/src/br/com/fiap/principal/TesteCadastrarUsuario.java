package br.com.fiap.principal;

import java.util.Scanner;

import javax.swing.JOptionPane;

import br.com.fiap.dao.UsuarioDAO;
import br.com.projeto.beans.Usuario;

public class TesteCadastrarUsuario {

	public static void main(String[] args) {
		Scanner entrada=new Scanner(System.in);
	UsuarioDAO dao=null;
	try {
	dao=new UsuarioDAO();
	Usuario usu=new Usuario();
	usu.setCodigo(Integer.parseInt(JOptionPane.showInputDialog("Digite o codigo de usuario")));
	usu.setNome(JOptionPane.showInputDialog("Digite o nome"));
	usu.setSenha(JOptionPane.showInputDialog("Digite a senha"));
	
	if(dao.addUser(usu)==0) {
		System.out.println("Nao cadastrado");
	}else {
		System.out.println("Cadastrado!");
	}

	
	

	}catch(Exception e ) {
		e.printStackTrace();
	}finally {
		try {
			dao.encerrar();
			
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
}
}
