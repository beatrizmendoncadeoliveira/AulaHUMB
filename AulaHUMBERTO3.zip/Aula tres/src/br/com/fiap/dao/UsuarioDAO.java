package br.com.fiap.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import br.com.projeto.beans.Usuario;

import br.com.fiap.conexao.Conexao;
public class UsuarioDAO {
	
	private Connection con;
	private PreparedStatement stmt;
	private ResultSet rs;
	public UsuarioDAO() throws Exception{
		con =Conexao.queroConectar();
	}
	
	public Usuario getUser(int codigo) throws Exception{
		stmt = con.prepareStatement
				("select * from RW_T_USUARIOO where ID_USUARIO=?");
		stmt.setInt(1, codigo);
		rs = stmt.executeQuery();
		if (rs.next()) {			
			return new Usuario(
					rs.getInt("ID_USUARIO"),
					rs.getString("NOME_USUARIO"),
					rs.getString("PW_USUARIO")
					);
		}else {
			return new Usuario();
		}
	}
	public int killUser(int cod)throws Exception {
		stmt=con.prepareStatement("delete from RW_T_USUARIOO where ID_USUARIO=?");
		stmt.setInt(1, cod);
		return stmt.executeUpdate();
	}	
		
	
	public int addUser(Usuario u)throws Exception {
		stmt=con.prepareStatement("INSERT INTO RW_T_USUARIOO (ID_USUARIO,NOME_USUARIO,PW_USUARIO) VALUES(?,?,?)");
		stmt.setInt(1, u.getCodigo());
		stmt.setString(2, u.getNome());
		stmt.setString(3, u.getSenha());
		return stmt.executeUpdate();
		
	}
	
	
	
	
	public void encerrar()throws Exception {
		con.close();
	}
	
	
	
}






