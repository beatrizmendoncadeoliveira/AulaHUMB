package br.com.projeto.beans;

public class Assinatura {
	private int codigo;
	private String tipo;
	private double valor;
	private Usuario usuario;
	private String data;
	public Assinatura(int codigo, String tipo, double valor, Usuario usuario, String data) {
		super();
		this.codigo = codigo;
		this.tipo = tipo;
		this.valor = valor;
		this.usuario = usuario;
		this.data = data;
	}
	public Assinatura() {
		super();
	}
	public int getCodigo() {
		return codigo;
	}
	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}
	public String getTipo() {
		return tipo;
	}
	public void setTipo(String tipo) {
		this.tipo = tipo;
	}
	public double getValor() {
		return valor;
	}
	public void setValor(double valor) {
		this.valor = valor;
	}
	public Usuario getUsuario() {
		return usuario;
	}
	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}
	public String getData() {
		return data;
	}
	public void setData(String data) {
		this.data = data;
	}
	
	
	

}
