package br.com.projeto.principal;

import br.com.projeto.dao.ProdutoDAO;

public class TesteSubTotal {

	public static void main(String[] args) {
		ProdutoDAO dao = null;
		try {
			dao = new ProdutoDAO();
			System.out.println("SubTotal: " + dao.getSubTotal(1));
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			try {
				dao.encerrar();
			}catch(Exception e) {
				e.printStackTrace();
			}
		}

	}

}
